import io, os, json, hashlib
from PIL import Image, ImageChops, ImageEnhance, ExifTags
import fitz

def image_to_bytes(img, fmt="PNG"):
    out=io.BytesIO()
    img.save(out, format=fmt)
    return out.getvalue()

def make_ela(img, quality=90, scale=12):
    """Create an ELA visualization. Interpret cautiously; it is not a forgery verdict."""
    img=img.convert("RGB")
    buf=io.BytesIO()
    img.save(buf, "JPEG", quality=quality)
    buf.seek(0)
    recompressed=Image.open(buf).convert("RGB")
    diff=ImageChops.difference(img, recompressed)
    extrema=diff.getextrema()
    max_diff=max([e[1] for e in extrema] or [1]) or 1
    factor=min(scale, 255/max_diff)
    return ImageEnhance.Brightness(diff).enhance(factor)

def analyze_image(img, raw_bytes):
    findings=[]
    score=0
    width,height=img.size
    digest=hashlib.sha256(raw_bytes).hexdigest()
    exif={}
    try:
        raw_exif=Image.open(io.BytesIO(raw_bytes)).getexif()
        for tag,val in raw_exif.items():
            exif[ExifTags.TAGS.get(tag,str(tag))]=str(val)[:300]
    except Exception:
        pass
    if not exif:
        findings.append("No readable EXIF metadata was found (common for screenshots and messaging-app images).")
        score+=8
    else:
        findings.append(f"Readable EXIF metadata found ({len(exif)} fields). Metadata can be edited or removed.")
        software=exif.get("Software")
        if software:
            findings.append(f"Software metadata: {software}")
            score+=12
    if width < 200 or height < 200:
        findings.append("Low image resolution may limit reliable forensic analysis.")
        score+=5
    if img.mode not in ("RGB","L"):
        findings.append(f"Non-standard color mode detected: {img.mode}")
        score+=4
    # ELA variability is a weak heuristic, deliberately capped.
    ela=make_ela(img)
    gray=ela.convert("L")
    hist=gray.histogram()
    total=sum(hist) or 1
    bright=sum(hist[180:])/total
    if bright > 0.12:
        findings.append("ELA contains relatively bright regions; uneven compression may be present.")
        score+=min(20, int(bright*100))
    else:
        findings.append("ELA did not show a strong high-brightness compression pattern.")
    findings.append("A single compression/metadata test cannot reliably prove whether an image was manipulated.")
    score=max(0,min(100,score))
    if score < 20: assessment="Lower indicator level"
    elif score < 45: assessment="Some indicators require review"
    else: assessment="Elevated indicators — manual review recommended"
    return {
        "file_type":"image", "dimensions":{"width":width,"height":height},
        "sha256":digest, "metadata":exif, "risk_score":score,
        "assessment":assessment, "findings":findings,
        "method":"Metadata inspection + heuristic ELA; no trained classifier included."
    }

def analyze_pdf(raw_bytes):
    doc=fitz.open(stream=raw_bytes, filetype="pdf")
    findings=[]
    image_count=0
    for page in doc:
        image_count += len(page.get_images(full=True))
    metadata=doc.metadata or {}
    if not metadata.get("author") and not metadata.get("creator"):
        findings.append("PDF author/creator metadata is absent.")
    else:
        findings.append("PDF contains author or creator metadata; metadata is not proof of authenticity.")
    if image_count:
        findings.append(f"{image_count} embedded image reference(s) found. Inspect them individually for edits.")
    else:
        findings.append("No embedded image references found; the PDF may primarily contain text or vector content.")
    findings.append("This prototype checks PDF structure and metadata only; it does not validate digital signatures or institutional records.")
    return {
        "file_type":"pdf", "pages":len(doc), "embedded_images":image_count,
        "indicator_count":len(findings), "metadata":metadata,
        "sha256":hashlib.sha256(raw_bytes).hexdigest(), "findings":findings
}
