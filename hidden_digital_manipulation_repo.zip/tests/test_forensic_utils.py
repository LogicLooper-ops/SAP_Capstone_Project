from PIL import Image
from forensic_utils import analyze_image, make_ela, analyze_pdf
import io, fitz

def sample_image():
    img=Image.new("RGB",(320,240),(120,140,160))
    b=io.BytesIO(); img.save(b,"PNG")
    return img,b.getvalue()

def test_image_analysis_has_expected_fields():
    img,raw=sample_image()
    result=analyze_image(img,raw)
    assert 0 <= result["risk_score"] <= 100
    assert len(result["sha256"]) == 64
    assert result["findings"]

def test_ela_returns_image():
    img,_=sample_image()
    result=make_ela(img)
    assert result.size == img.size

def test_pdf_analysis():
    doc=fitz.open()
    doc.new_page()
    raw=doc.tobytes()
    result=analyze_pdf(raw)
    assert result["pages"] == 1
    assert "sha256" in result
