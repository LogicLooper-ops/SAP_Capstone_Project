import streamlit as st
from PIL import Image
import io
import fitz
from forensic_utils import analyze_image, analyze_pdf, make_ela, image_to_bytes

st.set_page_config(page_title="Digital Manipulation Detector", page_icon="🕵️", layout="wide")
st.title("🕵️ AI-Powered Detection of Hidden Digital Manipulation")
st.caption("Digital forensics prototype • image, screenshot, scanned document and PDF analysis")

st.warning("Forensic indicators are not proof of fraud. Results are probabilistic and should be reviewed by a qualified examiner.")
uploaded = st.file_uploader("Upload an image or PDF", type=["jpg","jpeg","png","webp","tif","tiff","pdf"])

if uploaded:
    raw = uploaded.getvalue()
    name = uploaded.name
    if name.lower().endswith(".pdf"):
        with st.spinner("Analyzing PDF structure and embedded content..."):
            result = analyze_pdf(raw)
        st.subheader("PDF analysis")
        c1,c2,c3 = st.columns(3)
        c1.metric("Pages", result["pages"])
        c2.metric("Embedded images", result["embedded_images"])
        c3.metric("Risk indicators", result["indicator_count"])
        st.write("**Findings**")
        for item in result["findings"]:
            st.write(f"- {item}")
        st.download_button("Download analysis report (JSON)", json.dumps(result, indent=2), file_name="forensic_report.json", mime="application/json")
    else:
        try:
            img = Image.open(io.BytesIO(raw)).convert("RGB")
            with st.spinner("Checking image properties, metadata and compression..."):
                result = analyze_image(img, raw)
            left,right = st.columns(2)
            with left:
                st.image(img, caption="Uploaded image", use_container_width=True)
            with right:
                st.subheader("Analysis summary")
                st.metric("Manipulation risk score", f'{result["risk_score"]}/100')
                st.progress(result["risk_score"]/100)
                st.write(f'**Assessment:** {result["assessment"]}')
                st.write("**Findings**")
                for item in result["findings"]:
                    st.write(f"- {item}")
            st.subheader("Error Level Analysis (ELA)")
            st.caption("Bright or uneven areas can indicate different compression histories, but can also occur naturally.")
            ela = make_ela(img)
            st.image(ela, caption="ELA visualization", use_container_width=True)
            st.download_button("Download analysis report (JSON)", json.dumps(result, indent=2), file_name="forensic_report.json", mime="application/json")
        except Exception as e:
            st.error(f"Could not analyze this file: {e}")
