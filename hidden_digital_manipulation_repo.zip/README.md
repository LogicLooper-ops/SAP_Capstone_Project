# AI-Powered Detection of Hidden Digital Manipulation

A deployable Streamlit digital-forensics prototype for inspecting photographs, screenshots, scanned documents and PDFs for possible manipulation indicators.

## Features
- Upload JPG, PNG, WEBP, TIFF and PDF files
- Image dimensions and SHA-256 file fingerprint
- EXIF metadata inspection
- Error Level Analysis (ELA) visualization
- Heuristic risk indicator (0–100) with plain-language findings
- PDF page count, metadata and embedded-image count
- JSON report download
- Pytest unit tests
- Docker deployment and Render configuration

## Important limitations
This repository is a **working forensic prototype, not a certified forgery detector**. ELA and metadata can produce false positives and false negatives. A genuine image may have been resized, compressed, or stripped of metadata; a manipulated image may be recompressed to hide traces. The score is a heuristic indicator, not a probability of fraud.

The current version does not include a trained AI classifier, OCR-based certificate verification, PDF digital-signature validation, or comparison against an issuing institution's database. Those should be implemented as separate validated modules before claiming reliable AI detection.

## Run locally (Windows)
```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
streamlit run app.py
```
Open the local URL printed in the terminal (usually http://localhost:8501).

## Run tests
```powershell
python -m pytest -q
```

## Deploy on Render
1. Push this folder to a GitHub repository.
2. In Render, choose **New → Web Service** and connect the repository.
3. Render detects `render.yaml` / Dockerfile. Use the Docker environment.
4. Deploy and open the generated public URL.

## Deploy with Docker
```bash
docker build -t manipulation-detector .
docker run -p 8501:8501 manipulation-detector
```

## Suggested next research modules
1. Train and evaluate a CNN/ViT classifier on a documented image-tampering dataset.
2. Add OCR for extracting certificate fields and flagging layout/text inconsistencies.
3. Add PDF signature verification and certificate-chain checks.
4. Build a benchmark with authentic and manipulated examples; report precision, recall, F1 and false-positive rate.
5. Keep forensic indicators separate and explain which evidence caused each alert.

## Project architecture
```text
Upload → File-type routing
       ├─ Image → Metadata + SHA-256 + ELA → Findings + JSON
       └─ PDF   → Metadata + page/image inspection → Findings + JSON
```

## License
MIT
